<?php
$result = DB::select("meeting", null, "date_creted > ");

?>

meetings 


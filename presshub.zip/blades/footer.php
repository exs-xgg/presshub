<footer class="footer has-cards fix-bottom" style="">
    <div class="container">
      
      <hr>
      <div class="row align-items-center justify-content-md-between">
        <div class="col-md-6">
          <div class="copyright">
            &copy; 2018
            <a href="/" target="_blank">CCS Presshub</a>.
          </div>
        </div>
       
      </div>
    </div>
  </footer>


<style type="text/css">
    .fix-bottom{
  position: fixed; left: 0; bottom: 0; width: 100%
}
</style>
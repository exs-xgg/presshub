<?php

header("location: /");
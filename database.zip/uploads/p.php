<?php


php_info();

?>

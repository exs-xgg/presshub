<div class="tab-pane fade active show" id="tabs-icons-text-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                      <table class="table table-striped" id="assignedTable">
                        <thead>
                          <tr><th>Date Started</th><th>Issue</th><th>Article</th><th>Deadline</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                         
                          
                        </tbody>
                      </table>
                      <div class="small bg-secondary">
                        <small> • LEGEND •</small>
                        <ul>
                          <li class="text-danger">RED - Nearing Deadline / Overdue</li>
                        </ul>
                      </div>
                    </div>
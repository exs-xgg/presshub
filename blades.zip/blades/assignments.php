<div class="tab-pane fade active show" id="tabs-icons-text-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                      <table class="table table-striped" id="assignedTable">
                        <thead>
                          <tr><th>Date Started</th><th>Issue</th><th>Article</th><th>Deadline</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                          <tr class="text-danger"><td>2018-06-09</td><td>CCS 2nd Sem Red if late</td><td>News</td><td>2018-07-31</td><td><a class="link" href="/view/asd"><i class="fa fa-eye"></i> <b> View</b></a></td></tr>
                          
                        </tbody>
                      </table>
                      <div class="small bg-secondary">
                        <small> • LEGEND •</small>
                        <ul>
                          <li>Default</li>
                          <li class="text-danger">Nearing Deadline / Overdue</li>
                          <li class="text-primary">Fresh; less than a week since assigned</li>
                        </ul>
                      </div>
                    </div>